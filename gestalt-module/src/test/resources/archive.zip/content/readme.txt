This is a location used for testing module file sources - these are locations provided by modules
that expose files as content of a module.